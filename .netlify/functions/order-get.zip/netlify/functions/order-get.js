var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/order-get.ts
var order_get_exports = {};
__export(order_get_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(order_get_exports);
var handler = async (event) => {
  try {
    if (event.httpMethod !== "POST") return { statusCode: 405, body: "Use POST" };
    const { orderId } = JSON.parse(event.body || "{}");
    if (!orderId) return { statusCode: 400, body: "orderId required" };
    const base = process.env.SQUARE_ENV === "production" ? "https://connect.squareup.com" : "https://connect.squareupsandbox.com";
    const headers = {
      "Square-Version": "2023-10-18",
      Authorization: `Bearer ${process.env.SQUARE_ACCESS_TOKEN}`,
      "Content-Type": "application/json"
    };
    const res = await fetch(`${base}/v2/orders/${orderId}`, { headers });
    const data = await res.json();
    if (!res.ok || data.errors) return { statusCode: 500, body: JSON.stringify(data.errors || data) };
    const o = data.order;
    return {
      statusCode: 200,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        id: o.id,
        subtotalCents: o?.net_amounts?.subtotal_money?.amount ?? 0,
        totalCents: o?.total_money?.amount ?? 0,
        discounts: o?.discounts ?? [],
        lineItems: o?.line_items ?? []
      })
    };
  } catch (e) {
    return { statusCode: 500, body: e?.message || "error" };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
