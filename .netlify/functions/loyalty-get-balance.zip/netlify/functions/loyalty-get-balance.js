var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/loyalty-get-balance.ts
var loyalty_get_balance_exports = {};
__export(loyalty_get_balance_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(loyalty_get_balance_exports);
var import_supabase_js = require("@supabase/supabase-js");
var handler = async (event) => {
  try {
    if (event.httpMethod !== "POST") return { statusCode: 405, body: "Use POST" };
    const { phone, email } = JSON.parse(event.body || "{}");
    if (!phone && !email) return { statusCode: 400, body: "phone or email required" };
    const supabase = (0, import_supabase_js.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
    const { data: cust, error: cErr } = await supabase.from("customers").select("id").or(`phone.eq.${phone || ""},email.eq.${email || ""}`).maybeSingle();
    if (cErr) throw cErr;
    if (!cust) return { statusCode: 200, headers: { "content-type": "application/json" }, body: JSON.stringify({ points: 0 }) };
    const { data: bal, error: bErr } = await supabase.from("v_customer_points").select("points").eq("customer_id", cust.id).single();
    if (bErr) throw bErr;
    return { statusCode: 200, headers: { "content-type": "application/json" }, body: JSON.stringify({ points: bal?.points ?? 0 }) };
  } catch (e) {
    return { statusCode: 500, body: e?.message || "error" };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
