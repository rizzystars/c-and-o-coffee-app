var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/loyalty-send-otp.ts
var loyalty_send_otp_exports = {};
__export(loyalty_send_otp_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(loyalty_send_otp_exports);
var import_supabase_js = require("@supabase/supabase-js");
async function sendSms(to, body) {
  const sid = process.env.TWILIO_ACCOUNT_SID, tok = process.env.TWILIO_AUTH_TOKEN, from = process.env.TWILIO_FROM;
  if (!sid || !tok || !from) return { sent: false };
  const url = `https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`;
  const creds = Buffer.from(`${sid}:${tok}`).toString("base64");
  const res = await fetch(url, {
    method: "POST",
    headers: { Authorization: `Basic ${creds}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ From: from, To: to, Body: body })
  });
  return { sent: res.ok };
}
var handler = async (event) => {
  try {
    if (event.httpMethod !== "POST") return { statusCode: 405, body: "Use POST" };
    const { phone } = JSON.parse(event.body || "{}");
    if (!phone) return { statusCode: 400, body: "phone required" };
    const supabase = (0, import_supabase_js.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
    const code = Math.floor(1e5 + Math.random() * 9e5).toString();
    const expires = new Date(Date.now() + 5 * 60 * 1e3).toISOString();
    const { error } = await supabase.from("otp_codes").insert({ phone, code, expires_at: expires });
    if (error) throw error;
    const msg = `Your C&O Coffee code is ${code}. Expires in 5 minutes.`;
    const result = await sendSms(phone, msg);
    const body = { ok: true, sent: !!result.sent, demoCode: result.sent ? void 0 : code };
    return { statusCode: 200, headers: { "content-type": "application/json" }, body: JSON.stringify(body) };
  } catch (e) {
    return { statusCode: 500, body: e?.message || "error" };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
