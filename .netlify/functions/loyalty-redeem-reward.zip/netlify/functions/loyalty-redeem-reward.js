var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/loyalty-redeem-reward.ts
var loyalty_redeem_reward_exports = {};
__export(loyalty_redeem_reward_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(loyalty_redeem_reward_exports);
var import_supabase_js = require("@supabase/supabase-js");
var handler = async (event) => {
  try {
    if (event.httpMethod !== "POST") {
      return { statusCode: 405, headers: { "content-type": "application/json" }, body: JSON.stringify({ ok: false, error: "Use POST" }) };
    }
    const { userId, phone, email, pointsCost, rewardName } = JSON.parse(event.body || "{}");
    if (!userId && (!phone && !email) || !pointsCost || !rewardName) {
      return { statusCode: 400, headers: { "content-type": "application/json" }, body: JSON.stringify({ ok: false, error: "userId (or phone/email), pointsCost, and rewardName are required" }) };
    }
    const cost = Math.abs(Number(pointsCost || 0));
    if (!cost) {
      return { statusCode: 400, headers: { "content-type": "application/json" }, body: JSON.stringify({ ok: false, error: "Invalid pointsCost" }) };
    }
    const supabase = (0, import_supabase_js.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
    if (userId) {
      const { data: balRow, error: balErr } = await supabase.from("loyalty_balances").select("points").eq("user_id", userId).maybeSingle();
      if (balErr) throw balErr;
      const current = balRow?.points ?? 0;
      if (current < cost) {
        return { statusCode: 400, headers: { "content-type": "application/json" }, body: JSON.stringify({ ok: false, error: `Not enough points (need ${cost}, you have ${current})` }) };
      }
      const { error: ledgerErr } = await supabase.from("loyalty_ledger").insert({
        user_id: userId,
        delta: -cost,
        reason: `Redeem: ${rewardName}`
      });
      if (ledgerErr) throw ledgerErr;
      const { data: after, error: afterErr } = await supabase.from("loyalty_balances").select("points").eq("user_id", userId).single();
      if (afterErr) throw afterErr;
      return { statusCode: 200, headers: { "content-type": "application/json" }, body: JSON.stringify({ ok: true, rewardName, newBalance: after.points ?? current - cost }) };
    }
    const { data: cust, error: cErr } = await supabase.from("customers").select("id").or(`phone.eq.${phone || ""},email.eq.${email || ""}`).maybeSingle();
    if (cErr) throw cErr;
    if (!cust) {
      return { statusCode: 404, headers: { "content-type": "application/json" }, body: JSON.stringify({ ok: false, error: "Customer not found" }) };
    }
    const { data: bal, error: bErr } = await supabase.from("v_customer_points").select("points").eq("customer_id", cust.id).single();
    if (bErr) throw bErr;
    const legacyCurrent = bal?.points ?? 0;
    if (legacyCurrent < cost) {
      return { statusCode: 400, headers: { "content-type": "application/json" }, body: JSON.stringify({ ok: false, error: `Not enough points (need ${cost}, you have ${legacyCurrent})` }) };
    }
    const { error: legacyLedgerErr } = await supabase.from("points_ledger").insert({
      customer_id: cust.id,
      delta: -cost,
      reason: `Redeem: ${rewardName}`
    });
    if (legacyLedgerErr) throw legacyLedgerErr;
    const { data: bal2, error: bErr2 } = await supabase.from("v_customer_points").select("points").eq("customer_id", cust.id).single();
    if (bErr2) throw bErr2;
    return { statusCode: 200, headers: { "content-type": "application/json" }, body: JSON.stringify({ ok: true, rewardName, newBalance: bal2?.points ?? legacyCurrent - cost }) };
  } catch (e) {
    return { statusCode: 500, headers: { "content-type": "application/json" }, body: JSON.stringify({ ok: false, error: e?.message || "Server error" }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
