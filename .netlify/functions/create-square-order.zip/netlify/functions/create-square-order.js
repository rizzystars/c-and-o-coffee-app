var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/create-square-order.ts
var create_square_order_exports = {};
__export(create_square_order_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_square_order_exports);
var import_crypto = require("crypto");
var toCents = (n) => Math.round(Number(n) || 0);
var SQUARE_API_VERSION = "2024-05-15";
function resolveSquareConfig() {
  const env = (process.env.SQUARE_ENV || "sandbox").toLowerCase();
  const accessToken = process.env.SQUARE_ACCESS_TOKEN || (env === "production" ? process.env.SQUARE_PROD_ACCESS_TOKEN : process.env.SQUARE_SANDBOX_ACCESS_TOKEN);
  const locationId = process.env.SQUARE_LOCATION_ID || (env === "production" ? process.env.SQUARE_PROD_LOCATION_ID : process.env.SQUARE_SANDBOX_LOCATION_ID);
  return { env, accessToken, locationId };
}
var handler = async (event) => {
  if (event.httpMethod === "GET") {
    return { statusCode: 200, body: JSON.stringify({ ok: true, impl: "ORDER+PAYMENT" }) };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  try {
    const { env, accessToken, locationId } = resolveSquareConfig();
    if (!accessToken || !locationId) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Missing required Square configuration." })
      };
    }
    const body = JSON.parse(event.body || "{}");
    const idempotencyKey = body.idempotencyKey || (0, import_crypto.randomUUID)();
    const { sourceId, items = [], discount, notes, pickupTime, amountCents } = body;
    if (!sourceId) {
      return { statusCode: 400, body: JSON.stringify({ error: "Missing sourceId (card token)." }) };
    }
    const order = {
      location_id: locationId,
      line_items: items.map((item) => ({
        name: item.menuItem?.name || "Item",
        quantity: String(item.quantity || 1),
        base_price_money: {
          amount: toCents(item.menuItem?.price || 0),
          currency: "USD"
        }
      })),
      source: { name: "C&O Coffee Checkout" },
      note: `${notes || ""}${pickupTime ? ` | Pickup: ${pickupTime}` : ""}`
    };
    if (discount) {
      order.discounts = [
        {
          name: discount.label || discount.code || "Discount",
          amount_money: {
            amount: toCents(discount.amountCents || 0),
            currency: "USD"
          },
          scope: "ORDER"
        }
      ];
    }
    const orderResp = await fetch(`https://connect.squareup.com/v2/orders`, {
      method: "POST",
      headers: {
        "Square-Version": SQUARE_API_VERSION,
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        idempotency_key: idempotencyKey,
        order
      })
    });
    const orderData = await orderResp.json();
    if (!orderResp.ok) {
      return { statusCode: orderResp.status, body: JSON.stringify(orderData) };
    }
    const orderId = orderData.order?.id;
    if (!orderId) {
      return { statusCode: 500, body: JSON.stringify({ error: "Failed to create Square order." }) };
    }
    const paymentResp = await fetch(`https://connect.squareup.com/v2/payments`, {
      method: "POST",
      headers: {
        "Square-Version": SQUARE_API_VERSION,
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        idempotency_key: (0, import_crypto.randomUUID)(),
        source_id: sourceId,
        amount_money: {
          amount: toCents(amountCents),
          currency: "USD"
        },
        order_id: orderId,
        location_id: locationId
      })
    });
    const paymentData = await paymentResp.json();
    if (!paymentResp.ok) {
      return { statusCode: paymentResp.status, body: JSON.stringify(paymentData) };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        ok: true,
        env,
        order: orderData.order,
        payment: paymentData.payment
      })
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err?.message || "Server error" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
