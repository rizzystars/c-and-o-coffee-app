var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/list-catalog.ts
var list_catalog_exports = {};
__export(list_catalog_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(list_catalog_exports);
var handler = async () => {
  try {
    const { SQUARE_ACCESS_TOKEN, SQUARE_ENV, SQUARE_LOCATION_ID } = process.env;
    if (!SQUARE_ACCESS_TOKEN) {
      return { statusCode: 500, body: "Missing SQUARE_ACCESS_TOKEN" };
    }
    const base = SQUARE_ENV === "production" ? "https://connect.squareup.com" : "https://connect.squareupsandbox.com";
    const headers = {
      "Square-Version": "2023-10-18",
      "Authorization": `Bearer ${SQUARE_ACCESS_TOKEN}`,
      "Content-Type": "application/json"
    };
    const types = ["CATEGORY", "ITEM", "ITEM_VARIATION", "MODIFIER_LIST", "IMAGE"].join(",");
    let cursor;
    const objects = [];
    do {
      const url = new URL(`${base}/v2/catalog/list`);
      url.searchParams.set("types", types);
      if (cursor) url.searchParams.set("cursor", cursor);
      const res = await fetch(url.toString(), { headers });
      const data = await res.json();
      if (!res.ok || data.errors) {
        return { statusCode: 500, body: JSON.stringify(data.errors || data) };
      }
      objects.push(...data.objects || []);
      cursor = data.cursor;
    } while (cursor);
    const byId = new Map(objects.map((o) => [o.id, o]));
    const items = objects.filter((o) => o.type === "ITEM");
    const imageUrlForId = (imgId) => {
      if (!imgId) return null;
      const img = byId.get(imgId);
      return img?.image_data?.url || null;
    };
    const menuItems = [];
    for (const item of items) {
      const data = item.item_data;
      if (!data) continue;
      const catName = data.category_id ? byId.get(data.category_id)?.category_data?.name : "Uncategorized";
      const itemImage = imageUrlForId(data.image_id);
      const modListIds = (data.modifier_list_info || []).map((m) => m.modifier_list_id);
      const modifierGroups = modListIds.map((id) => byId.get(id)).filter(Boolean).map((ml) => ({
        id: ml.id,
        name: ml.modifier_list_data?.name,
        options: (ml.modifier_list_data?.modifiers || []).map((m) => ({
          id: m.id,
          name: m.modifier_data?.name,
          price: m.modifier_data?.price_money?.amount ?? 0
        }))
      }));
      for (const v of data.variations || []) {
        const vd = v.item_variation_data;
        if (!vd) continue;
        if (process.env.SQUARE_LOCATION_ID) {
          const present = v.present_at_location_ids || [];
          const absent = v.absent_at_location_ids || [];
          if (present.length && !present.includes(process.env.SQUARE_LOCATION_ID)) continue;
          if (absent.length && absent.includes(process.env.SQUARE_LOCATION_ID)) continue;
        }
        const price = vd.price_money?.amount;
        if (price == null) continue;
        const size = vd.name ? ` ${vd.name}` : "";
        menuItems.push({
          id: v.id,
          name: `${data.name}${size}`,
          category: catName,
          description: data.description || null,
          price,
          imageUrl: itemImage,
          stock: 999,
          isActive: data.is_archived ? false : true,
          modifierGroups
        });
      }
    }
    menuItems.sort((a, b) => (a.category || "").localeCompare(b.category || "") || a.name.localeCompare(b.name));
    return {
      statusCode: 200,
      headers: { "content-type": "application/json", "cache-control": "public, max-age=60" },
      body: JSON.stringify({ items: menuItems })
    };
  } catch (e) {
    return { statusCode: 500, body: e?.message || "Internal error" };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
