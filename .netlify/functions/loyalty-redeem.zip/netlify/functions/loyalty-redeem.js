var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/loyalty-redeem.ts
var loyalty_redeem_exports = {};
__export(loyalty_redeem_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(loyalty_redeem_exports);
var import_supabase_js = require("@supabase/supabase-js");
var VALUE_PER_POINT_CENTS = 5;
var MAX_PERCENT_OFF = 100;
var handler = async (event) => {
  try {
    if (event.httpMethod !== "POST") {
      return { statusCode: 405, body: "Method Not Allowed. Please use POST." };
    }
    const { phone, email, orderId, pointsToSpend } = JSON.parse(event.body || "{}");
    if (!orderId || !pointsToSpend || !phone && !email) {
      return { statusCode: 400, body: "orderId, pointsToSpend, and a customer identifier (phone or email) are required." };
    }
    const squareApiBase = process.env.SQUARE_ENV === "production" ? "https://connect.squareup.com" : "https://connect.squareupsandbox.com";
    const squareHeaders = {
      "Square-Version": "2024-05-15",
      // Using a recent API version
      "Authorization": `Bearer ${process.env.SQUARE_ACCESS_TOKEN}`,
      "Content-Type": "application/json"
    };
    const supabase = (0, import_supabase_js.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
    const { data: customer, error: custErr } = await supabase.from("customers").upsert({ phone, email }, { onConflict: "phone,email" }).select("id").single();
    if (custErr) throw custErr;
    const { data: balance, error: balErr } = await supabase.from("v_customer_points").select("points").eq("customer_id", customer.id).single();
    if (balErr) throw balErr;
    const availablePoints = balance?.points ?? 0;
    if (pointsToSpend > availablePoints) {
      return { statusCode: 400, body: `Insufficient points. You have ${availablePoints}, but tried to spend ${pointsToSpend}.` };
    }
    const orderRes = await fetch(`${squareApiBase}/v2/orders/${orderId}`, { headers: squareHeaders });
    const orderJson = await orderRes.json();
    if (!orderRes.ok || orderJson.errors) {
      return { statusCode: orderRes.status, body: JSON.stringify(orderJson.errors || { error: "Failed to fetch Square order." }) };
    }
    const order = orderJson.order;
    const subtotalCents = order?.net_amounts?.subtotal_money?.amount ?? order?.total_money?.amount ?? 0;
    const requestedDiscount = pointsToSpend * VALUE_PER_POINT_CENTS;
    const maxDiscountByPercentage = Math.floor(subtotalCents * MAX_PERCENT_OFF / 100);
    const actualDiscountCents = Math.min(requestedDiscount, maxDiscountByPercentage, subtotalCents);
    if (actualDiscountCents <= 0) {
      return { statusCode: 200, body: JSON.stringify({ applied: 0, pointsSpent: 0, message: "No discount applied." }) };
    }
    const updateRes = await fetch(`${squareApiBase}/v2/orders/${orderId}`, {
      method: "PUT",
      headers: squareHeaders,
      body: JSON.stringify({
        order: {
          location_id: order.location_id,
          // Use location_id from the fetched order
          discounts: [{
            name: "Loyalty Points Redemption",
            scope: "ORDER",
            type: "FIXED_AMOUNT",
            amount_money: { amount: actualDiscountCents, currency: "USD" }
          }],
          version: order.version
          // The order version is required for updates
        },
        idempotency_key: randomUUID()
      })
    });
    const updateJson = await updateRes.json();
    if (!updateRes.ok || updateJson.errors) {
      return { statusCode: updateRes.status, body: JSON.stringify(updateJson.errors || { error: "Failed to apply discount to Square order." }) };
    }
    const pointsActuallySpent = Math.ceil(actualDiscountCents / VALUE_PER_POINT_CENTS);
    const { error: ledgerErr } = await supabase.from("points_ledger").insert({
      customer_id: customer.id,
      delta: -pointsActuallySpent,
      reason: "Redeemed points for order discount",
      square_order_id: orderId
    });
    if (ledgerErr) {
      console.error("CRITICAL: Failed to deduct points after applying discount.", ledgerErr);
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        applied: actualDiscountCents,
        pointsSpent: pointsActuallySpent,
        currency: "USD",
        order: updateJson.order
        // Return the updated order from Square
      })
    };
  } catch (e) {
    console.error("An unexpected error occurred in loyalty-redeem:", e);
    return { statusCode: 500, body: JSON.stringify({ error: e?.message || "An internal server error occurred." }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
