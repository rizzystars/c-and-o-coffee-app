var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/pay-square-order.js
var pay_square_order_exports = {};
__export(pay_square_order_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(pay_square_order_exports);
var crypto = require("crypto");
async function handler(event) {
  try {
    if (event.httpMethod !== "POST") {
      return { statusCode: 405, body: "Method Not Allowed" };
    }
    const {
      sourceId,
      // required: token from card.tokenize()
      amount,
      // required: integer cents
      currency = "USD",
      // optional
      orderId,
      // optional
      customerId,
      // optional
      note
      // optional
    } = JSON.parse(event.body || "{}");
    if (!sourceId) {
      return json(400, { error: "Missing sourceId" });
    }
    if (!Number.isInteger(amount) || amount <= 0) {
      return json(400, { error: "Invalid amount (cents required)" });
    }
    const accessToken = process.env.SQUARE_ACCESS_TOKEN;
    if (!accessToken) {
      return json(500, { error: "Server missing SQUARE_ACCESS_TOKEN" });
    }
    const env = (process.env.SQUARE_ENV || "production").toLowerCase();
    const baseUrl = env === "sandbox" ? "https://connect.squareupsandbox.com" : "https://connect.squareup.com";
    const locationId = process.env.SQUARE_LOCATION_ID && process.env.SQUARE_LOCATION_ID.trim().length > 0 ? process.env.SQUARE_LOCATION_ID.trim() : void 0;
    if (env === "production" && amount > 5e4) {
      return json(400, { error: "Amount exceeds temporary server cap" });
    }
    const idempotencyKey = crypto.randomUUID();
    const payload = {
      source_id: sourceId,
      idempotency_key: idempotencyKey,
      amount_money: { amount, currency },
      ...locationId ? { location_id: locationId } : {},
      ...orderId ? { order_id: orderId } : {},
      ...customerId ? { customer_id: customerId } : {},
      ...note ? { note } : {}
    };
    const resp = await fetch(`${baseUrl}/v2/payments`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
        "Square-Version": "2024-09-18"
      },
      body: JSON.stringify(payload)
    });
    const data = await resp.json();
    if (!resp.ok) {
      console.error("Square /v2/payments error:", data);
      return json(resp.status, { error: data.errors || data });
    }
    return json(200, data);
  } catch (err) {
    console.error("pay-square-order fatal:", err);
    return json(500, { error: err.message || "Unknown server error" });
  }
}
function json(statusCode, obj) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(obj)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
