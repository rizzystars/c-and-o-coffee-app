var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/pay-square-order.ts
var pay_square_order_exports = {};
__export(pay_square_order_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(pay_square_order_exports);
function resolveSquareConfig() {
  const env = (process.env.SQUARE_ENV || "sandbox").toLowerCase();
  const accessToken = process.env.SQUARE_ACCESS_TOKEN || (env === "production" ? process.env.SQUARE_PROD_ACCESS_TOKEN : process.env.SQUARE_SANDBOX_ACCESS_TOKEN);
  const locationId = process.env.SQUARE_LOCATION_ID || (env === "production" ? process.env.SQUARE_PROD_LOCATION_ID : process.env.SQUARE_SANDBOX_LOCATION_ID);
  return { env, accessToken, locationId };
}
var handler = async (event) => {
  if (event.httpMethod === "GET") {
    return { statusCode: 200, body: JSON.stringify({ ok: true, impl: "FETCH_V1" }) };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  try {
    const { env, accessToken, locationId } = resolveSquareConfig();
    if (!accessToken || !locationId) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Missing required Square configuration." })
      };
    }
    const body = JSON.parse(event.body || "{}");
    const { orderId, idempotencyKey, amount, sourceId } = body;
    if (amount === 0) {
      return {
        statusCode: 200,
        body: JSON.stringify({
          payment: {
            id: `ZERO_DOLLAR_${orderId}`,
            status: "COMPLETED",
            amount_money: { amount: 0, currency: "USD" },
            order_id: orderId
          }
        })
      };
    }
    if (!orderId || !idempotencyKey || typeof amount !== "number" || !sourceId) {
      return { statusCode: 400, body: JSON.stringify({ error: "Missing required payment fields." }) };
    }
    const paymentPayload = {
      source_id: sourceId,
      idempotency_key: idempotencyKey,
      amount_money: {
        amount: Math.max(0, Math.trunc(amount || 0)),
        currency: "USD"
      },
      order_id: orderId,
      location_id: locationId
    };
    const response = await fetch(`https://connect.squareup.com/v2/payments`, {
      method: "POST",
      headers: {
        "Square-Version": "2024-05-15",
        "Authorization": `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(paymentPayload)
    });
    const data = await response.json();
    if (!response.ok) {
      return { statusCode: response.status, body: JSON.stringify(data) };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({ payment: data.payment })
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err?.message || "Server error" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
