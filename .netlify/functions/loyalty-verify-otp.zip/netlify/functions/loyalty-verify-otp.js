var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/loyalty-verify-otp.ts
var loyalty_verify_otp_exports = {};
__export(loyalty_verify_otp_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(loyalty_verify_otp_exports);
var import_supabase_js = require("@supabase/supabase-js");
var handler = async (event) => {
  try {
    if (event.httpMethod !== "POST") return { statusCode: 405, body: "Use POST" };
    const { phone, code } = JSON.parse(event.body || "{}");
    if (!phone || !code) return { statusCode: 400, body: "phone and code required" };
    const supabase = (0, import_supabase_js.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
    const { data: rows, error } = await supabase.from("otp_codes").select("*").eq("phone", phone).order("created_at", { ascending: false }).limit(1);
    if (error) throw error;
    const row = rows?.[0];
    if (!row) return { statusCode: 400, body: "no code issued" };
    if (new Date(row.expires_at) < /* @__PURE__ */ new Date()) return { statusCode: 400, body: "code expired" };
    if (row.code !== code) {
      await supabase.from("otp_codes").update({ attempts: row.attempts + 1 }).eq("id", row.id);
      return { statusCode: 400, body: "invalid code" };
    }
    return { statusCode: 200, headers: { "content-type": "application/json" }, body: JSON.stringify({ ok: true }) };
  } catch (e) {
    return { statusCode: 500, body: e?.message || "error" };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
